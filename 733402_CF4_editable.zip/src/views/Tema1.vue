<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido
      .titulo-principal__numero
        span 1
      h1 Evaluación del proyecto

    .row.justify-content-center.align-items-center.mb-5(data-aos="zoom-in")
      .col-lg-8      
        p La evaluación de un proyecto se fundamenta en la necesidad de establecer las técnicas para determinar lo que está sucediendo y cómo ha ocurrido, para apuntar hacia lo que encierra el futuro si no se interviene, por lo que la medición de factores concurrentes y coadyuvantes, permite deﬁnir la factibilidad de ejecución del proyecto (Graterol, 2010). 
        p La evaluación de proyectos puede hacerse desde dos puntos de vista que no son opuestos, pero sí distintos: el primero corresponde al criterio privado y el segundo es el criterio social, de acuerdo con la perspectiva que se encamine la evaluación, dependerá la decisión que se tome en relación con la realización del proyecto. 
        p Dicho lo anterior, la evaluación de un proyecto signiﬁca analizar el proceso de transformación, de cambio o de mudanza y valorar su signiﬁcado; es por ello que, en este análisis, es necesario obtener y comparar magnitudes, someterlas a juicio y conseguir resultados concretos que señalen cómo se debe proseguir en la transformación de una situación y a costa de qué esfuerzo (Córdoba 2011).
      .col-lg-4.col-md-8
        figure
          img(src='@/assets/curso/temas/tema1/img-1.png', alt='')
    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      .col-lg-10.fnd-1.p-4
        p.mb-0 A su vez, para la evaluación del proyecto, es indispensable tomar los valores del flujo neto de caja, que agrupa el flujo neto de inversión, operación y financiamiento, para luego aplicar los indicadores financieros los cuales darán a conocer la viabilidad del proyecto y si es recomendable invertir en este (Puentes, 2011).
    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 Objetivos de la evaluación
      p.mb-5 Según Córdoba, (2011), la evaluación de un proyecto persigue los siguientes objetivos:


      .col-lg-4
        .crd_02.mb-5
          .crd_02__icon.dan
            img(src="@/assets/curso/temas/tema1/img-3.svg", alt="alt")          
          .crd_02__txt
            p.text-bold Examinar los proyectos vigentes y deﬁnir con precisión lo que se pretende con la evaluación.
      .col-lg-3
        .crd_02.mb-5
          .crd_02__icon.dan
            img(src="@/assets/curso/temas/tema1/img-4.svg", alt="alt")          
          .crd_02__txt
            p.text-bold Medir los resultados a través de indicadores.
      .col-lg-5
        .crd_02.mb-5
          .crd_02__icon.dan
            img(src="@/assets/curso/temas/tema1/img-5.svg", alt="alt")          
          .crd_02__txt
            p.text-bold Determinar la eﬁcacia de las actividades utilizadas y eﬁciencia de los recursos, en función de los indicadores, de la cantidad empleada de los mismos y de sus costos.            

    .row.justify-content-center.align-items-center.mb-5(data-aos="zoom-in")
      .col-lg-8
        p Se considera que el ciclo de vida de un proyecto, finaliza en el momento que se efectúan los desembolsos de efectivo, o sea, cuando se habla de la etapa de ejecución, sin embargo, la vida de un proyecto consta de otras etapas, como se muestra en la figura 1, resaltando además, que las fases del proyecto y las actividades de evaluación se relacionan. 

    .row.justify-content-center.align-items-center(data-aos="fade-right")
      .col-lg-10
        .titulo-sexto.color-acento-contenido
          h5 Figura 1.
          span Fases del proyecto
        .row.justify-content-center.align-items-center.mb-4
          .col-lg-12
            figure.mb-5
              img(src='@/assets/curso/temas/tema1/img-6.svg', alt='La figura muestra la jerarquía de las normas de Colombia. 1-Preparacion del proyecto. 2-Ejecucion/terminación del proyecto. 3-Operacion/Post-proyecto.')
            figcaption Nota. Elaboración propia.

    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      .col-lg-8
        .row.justify-content-start.align-items-center
          p.mb-5 El ciclo de vida de un proyecto comienza en la etapa de preparación, continuando con la etapa de ejecución y finalizando con la operación, la evaluación se relaciona en cada una de las fases, resaltando que, para cada fase del ciclo de vida del proyecto, se desarrollan las siguientes tareas:

          .img-fnd-flot8.mb-3
            img.b-img9(src='@/assets/curso/temas/tema1/fnd--.svg' alt='Background Image')
            .fl-box8
              h3.mb-0 Etapa de preparación                 
          p.mb-5 En esta etapa se efectúa la Matriz de Marco Lógico, con el fin de determinar el propósito del proyecto, sus fines y los supuestos que se puedan presentar en la ejecución del proyecto.
 
          .img-fnd-flot8.mb-3
            img.b-img8(src='@/assets/curso/temas/tema1/fnd--.svg' alt='Background Image')
            .fl-box8
              h3.mb-0 Etapa de ejecución   
          p.mb-5 En la etapa de ejecución se efectúa el desempeño y desarrollo del proyecto, esto con el fin de elaborar informes de seguimiento, que permitan gestionar ajustes a lo evidenciado en el monitoreo y evaluación.
 
          .img-fnd-flot8.mb-3
            img.b-img8(src='@/assets/curso/temas/tema1/fnd--.svg' alt='Background Image')
            .fl-box8
              h3.mb-0 Etapa de operación                
          p En esta etapa se examina el impacto del proyecto, esto con el fin de generar informes con recomendaciones que sirvan de aprendizaje para futuros proyectos.                
      .col-lg-4.col-md-8
        figure.mb-3
          img(src='@/assets/curso/temas/tema1/img-10.png', alt='')      
    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 Tipos de evaluación

      p Para cada fase del ciclo de vida del proyecto, se encuentran diferentes tipos de evaluación, cuyo fin es el medir la asignación de los recursos. En la literatura se pueden encontrar diferentes tipologías de evaluaciones del ciclo de vida de los proyectos, sin embargo, se abordaron dos en este documento.


    .row.justify-content-center.align-items-stretch(data-aos="fade-right")
      .col-xl-7
        .row.justify-content-center.align-items-center.mb-5.fnd-3.fnd-3-1
          .col-lg-8.col-md-10
            h5.mb-0 La primera tipología está conformada por cuatro aspectos:
            p.mb-0  <b>Evaluación ex-ante:</b> esta etapa evalúa la fase de preparación del proyecto, es decir, la problemática, las necesidades, la población objetivo.
            p.mb-0  <b>La evaluación intra:</b> esta evaluación se efectúa en la fase de ejecución, aquí se evalúan las actividades en desarrollo.
            p.mb-0  <b>La evaluación post:</b> esta fase corresponde con la finalización de la ejecución del proyecto, analizando los resultados obtenidos.
            p.mb-0  <b>La evaluación ex-post:</b> esta fase se realiza después de haber terminado la ejecución del proyecto, se evalúan los resultados, centrándose en los impactos del proyecto.
          .col-lg-4.col-md-10
            figure.fl-box-img
              img.img-297(src='@/assets/curso/temas/tema1/img-11-.png' alt='Background Image')
      .col-xl-5
        .row.justify-content-center.align-items-center.mb-3.fnd-3.fnd-3-2
          .col-xl-7.col-lg-8.col-md-10
            h5 La segunda tipología es la propuesta por el Banco Interamericano de Desarrollo (BID), la cual considera dos tipos de evaluaciones:
            p.mb-0 <b>Formativa:</b> se realiza en la etapa de preparación y ejecución del proyecto.
            p <b>Sumativa:</b> se realiza después de terminado el proyecto.
          .col-xl-5.col-lg-4.col-md-10
            figure.fl-box-img             
              img.img-297(src='@/assets/curso/temas/tema1/img-12-.png' alt='Background Image')


    Separador
    #1_1.titulo-segundo.color-acento-contenido(data-aos="zoom-in")
      h2 1.1 Evaluación financiera

    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      .col-lg-3.mb-5.col-md-8
        figure 
          img(src='@/assets/curso/temas/tema1/img-13.png', alt='')
      .col-lg-9.fnd-2.p-4
        p La evaluación financiera de proyectos puede considerarse como el ejercicio mediante el cual se intentan identificar los costos y beneficios de un proyecto, con la finalidad de tomar la decisión más acertada.
        p La evaluación financiera, permite identificar si el proyecto es viable, dada sus inversiones, sus ingresos y egresos durante un periodo de tiempo, reconociendo sus pérdidas o ganancias; esta evaluación se efectúa a través de criterios como el Valor Presente Neto (VPN), la Tasa Interna de Retorno (TIR) y la relación Costo – Beneficio, esto lo podemos apreciar en la figura que se propone a continuación:

    .row.justify-content-center.align-items-center(data-aos="fade-right")
      .col-lg-10
        .titulo-sexto.color-acento-contenido
          h5 Figura 2.
          span Proceso evaluación financiera
        .row.justify-content-center.align-items-center
          .col-lg-12
            figure.mb-5
              img.mb-3(src='@/assets/curso/temas/tema1/img-14.svg', alt='La figura 2 esquematiza el proceso de la evaluación financiera, la cual parte de un flujo de inversiones, ya sean de índole, público o privado, pasando por una evaluación de indicadores financieros (VAN, TIR, R B/C), finalizando con el análisis respectivo, que permita tomar la decisión de llevar a cabo o no la ejecución del proyecto.')
              figcaption Nota. Elaboración propia.
        p La figura 2 esquematiza el proceso de la evaluación financiera, la cual parte de un flujo de inversiones, ya sean de índole, público o privado, pasando por una evaluación de indicadores financieros (VAN, TIR, R B/C), finalizando con el análisis respectivo, que permita tomar la decisión de llevar a cabo o no la ejecución del proyecto.

    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 Indicadores financieros para evaluar proyectos
      .col-lg-4.col-md-8
        figure.mb-5
          img(src='@/assets/curso/temas/tema1/img-15.png', alt='')    
      .col-lg-8
        p.mb-0 A la hora de hablar de indicadores financieros, es importante decir, que un indicador es aquella variable que intenta medir de forma cuantitativa o cualitativa, características o comportamientos reales.
        p En el momento de analizar si es pertinente realizar o no un proyecto de inversión, es necesario utilizar ciertos indicadores financieros, los cuales permitirán establecer la viabilidad del proyecto. 
        p Para efectuar un correcto análisis de la situación financiera del proyecto, es necesario efectuar los tres indicadores propuestos, aunque estos de manera individual tienen sus pros y sus contras, analizados de manera conjunta permite tomar decisiones basadas en los resultados.
        p Los indicadores financieros que se utilizan con mayor frecuencia para la evaluación de proyectos de inversión son: Valor Presente Neto (VAN), Tasa Interna de Retorno (TIR) y la Relación Costo - Beneficio. 



    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 Valor Actual Neto o Valor Presente Neto (VAN)
      p El Valor Presente Neto es el valor que resulta de traer los flujos netos al valor presente con la tasa de interés de oportunidad y restarle las inversiones; esta función se puede calcular en el programa de Office Excel, con la función financiera llamada VNA.
      p Para interpretar el Valor Presente Neto se dice que:
    .row.justify-content-center.align-items-center(data-aos="zoom-in")

          .col-lg-3
            .crd_02.mb-5
              .crd_02__icon.dan
                img(src="@/assets/curso/temas/tema1/img-16.svg", alt="alt")          
              .crd_02__txt
                h6.mb-0 Si el Valor Presente Neto es mayor a cero se acepta el proyecto.
          .col-lg-3
            .crd_02.mb-5
              .crd_02__icon.dan
                img(src="@/assets/curso/temas/tema1/img-17.svg", alt="alt")          
              .crd_02__txt
                h6.mb-0Si el Valor Presente Neto es menor a cero se rechaza el proyecto.
          .col-lg-4
            .crd_02.mb-5
              .crd_02__icon.dan
                img(src="@/assets/curso/temas/tema1/img-18.svg", alt="alt")          
              .crd_02__txt
                h6.mb-0 Si el Valor Presente Neto es igual a cero se es indiferente el proyecto y quedará a criterio del evaluador si lo acepta o lo rechaza.            


    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      .col-lg-12
        .titulo-sexto.color-acento-contenido
          h5 Tabla 1. 
          span Valoración VNA
        .tabla-b.color-acento-contenido.mb-5.ttbl2
          table
            caption Nota. Elaboración propia (2021).
            tr
              th.t1 Valor
              th.t2 Significado
              th.t3 Decisión 
            tr
              td VNA > 0
              td La inversión producirá ganancias
              td Se acepta el proyecto 
            tr
              td VNA < 0
              td La inversión no producirá ganancias
              td Se rechaza el proyecto 
            tr
              td VNA = 0
              td La inversión no producirá ni ganancias ni pérdidas
              td
                | Se es indiferente el proyecto, y la decisión de si se acepta o se rechaza, deberá ser tomada basada en otros criterios


    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      .col-lg-12
        .titulo-sexto.color-acento-contenido
          h5 Tabla 2. 
          span Flujo Neto para cálculo del VNA
        .tabla-b.color-acento-contenido.ttbl2
          table
            caption Nota. Elaboración propia (2021).

            tr
              th
              th.t4 Periodo 0
              th.t5 Periodo 1
              th.t6 Periodo 2
              th.t7 Periodo 3
              th.t8(rowspan='5') Tasa de oportunidad 18 %
            tr
              td Inversión inicial
              td $10.000.000
              td                
              td                
              td                
            tr
              td Flujo neto
              td $-10.000.000
              td $1.200.000
              td $6.500.000
              td $8.700.000
            

    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 ¿Cómo calcular el Valor Presente Neto?              

      p Para calcular lo primero que deben hacer es pasar los datos al archivo en Excel, como se muestra en la siguiente figura:
    
    .row.justify-content-center.align-items-center.mb-5.fnd-4(data-aos="zoom-in")
      .col-lg-12.p-4        
        SlyderA.fnd-5.p-4(tipo="b")
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 1
              p Para calcular lo primero que deben hacer es pasar los datos al archivo en Excel, como se muestra en la siguiente figura:
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-19.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 2
              p Después de tener los datos en el archivo de Excel se procede a digitar igual seguido de la palabra VAN y se le da clic en insertar función, como se muestra en la siguiente figura:
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-20.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 3
              p Ahora se debe dar clic en insertar función aparece el siguiente cuadro de diálogo.
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-21.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 4
              p En la celda de Tasa se refiere a la tasa de oportunidad, la celda de valores, corresponden a los flujos netos, como se ilustra en la presente figura.
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-22.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 5
              p Finalmente, al resultado se le suma el flujo neto de la inversión, correspondiente al periodo 0.
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-23.png')
      

    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 Tasa Interna de Retorno (TIR)

      p La Tasa Interna de Retorno (TIR), es el reflejo de la tasa de interés o de rentabilidad que el proyecto arrojará periodo a periodo durante su vida útil. La TIR se compara con la tasa de oportunidad y se aceptan aquellos proyectos en los que la TIR es igual o superior.
      p Para interpretar la TIR se dice que:
          
    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      .col-lg-12
        .titulo-sexto.color-acento-contenido
          h5 Tabla 3. 
          span Valoración VNA
        .tabla-b.color-acento-contenido.ttbl2
          table
            caption Nota. Elaboración propia (2021).
            tr
              th.t7(colspan='2') Valoración VNA
            tr
              th.t4 Valor 
              th.t2 Decisión
            tr
              td TIR > tasa de interés de oportunidad	
              td Se acepta el proyecto
            tr
              td TIR < tasa de interés de oportunidad	
              td Se rechaza el proyecto              
            tr
              td TIR = tasa de interés de oportunidad	
              td Se es indiferente frente al proyecto, y la decisión de si se acepta o se rechaza, deberá ser tomada basada en otros criterios          

    p A continuación, se puede visualizar un ejemplo de la Tasa Interna de Retorno en una hoja de cálculo:
    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      .col-lg-12
        .titulo-sexto.color-acento-contenido
          h5 Tabla 4. 
          span Flujo Neto para cálculo de la TIR
        .tabla-b.color-acento-contenido.ttbl2
          table
            caption Nota. Elaboración propia (2021)

            tr
              th
              th.t4 Periodo 0
              th.t5 Periodo 1
              th.t6 Periodo 2
              th.t7 Periodo 3
              th.t8(rowspan='5') Tasa de oportunidad 18%.
            tr
              td Inversión inicial
              td $10.000.000
              td                
              td                
              td                
            tr
              td Flujo neto
              td $-10.000.000
              td $12.000.000
              td $6.500.000
              td $8.700.000


    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 ¿Cómo calcular la Tasa Interna de Retorno?      

    .row.justify-content-center.align-items-center.mb-5.fnd-6(data-aos="zoom-in")
      .col-lg-12.p-4        
        SlyderA.fnd-6-.p-4(tipo="b")
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 1
              p Para calcular lo primero que deben hacer es pasar los datos al archivo en Excel, como se muestra en la siguiente figura:
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-24.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 2
              p Después de tener los datos en el archivo de Excel se procede a digitar igual seguido de la palabra TIR y se le da clic en insertar función, como lo ilustra la figura.
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-25.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 3
              p Después de dar clic en insertar función aparece el siguiente cuadro de diálogo:
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-26.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 4
              p En la celda de Valores se deben seleccionar todos los flujos netos incluyendo el periodo 0, como se ilustra en la presente figura:
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-27.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 5
              p Finalmente, se le da enter y se obtiene el resultado correspondiente a la TIR, como se muestra en la siguiente figura:
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-28.png')


    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 Relación Beneficio - Costo  R B/C
      .col-lg-8
        p La relación costo - beneficio, es la relación presente de los flujos netos a la inversión inicial. En la R B/Cel VAN de los ingresos es mayor al VAN de los egresos, sumado la inversión, es superior a 1 en un periodo de tiempo con una tasa de oportunidad. 
        p Dado lo anterior, se puede decir que los ingresos son suficientes para cubrir todos los costos y además dan un excedente por cada peso invertido del restante del valor de 1, ante esta situación se habla de un proyecto viable financieramente.
        p A continuación, se puede visualizar un ejemplo de la Relación Beneficio - Costo en una hoja de cálculo:
      .col-lg-4.col-md-10
        figure.p-4
          img(src='@/assets/curso/temas/tema1/img-29.png')


    .row.justify-content-center.align-items-center.mb-3(data-aos="fade-left")
      .col-lg-12
        .titulo-sexto.color-acento-contenido
          h5 Tabla 5. 
          span Flujo Neto para cálculo de la R B/C

    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      .col-xl-8
        
        .tabla-b.color-acento-contenido.ttbl3.mb-3
          table
            
            tr
              th.t1.text-bold(colspan='4') Flujo de caja
            tr
              th.t2 Periodo
              th.t3 Inversión
              th.t4 Ingresos
              th.t5 Egresos 
            tr
              td 0	  
              td $10.000.000 	
              td 0	
              td 0              
            tr
              td 1
              td 
              td $8.500.000
              td $2.500.000 
            tr
              td 2
              td 
              td $5.000.000
              td $3.200.000 
            tr
              td 3
              td 
              td $12.500.000
              td $5.800.000 
            tr
              td 4
              td 
              td $10.200.000
              td $7.400.000 
            tr
              td 5
              td 
              td $8.700.000
              td $4.250.000 
      .col-xl-4
        .ttbl3.mb-3
          table
            tr
              th.t6 Inversión
              td.t7 $10.000.000
          table              
            tr
              th.t8 Tasa de descuento  
              td.t9 18 %

        .ttbl3
          table
            tr
              th.t10 VNA Ingresos
              td          
            tr
              th.t11 VNA Egresos	  
              td          
            tr
              th.t12 VNA + Inversión	  
              td          
            tr
              th.t5 Beneficio - Costo	  
              td          
      figcaption.mt-4 Nota. Elaboración propia (2021).



    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 ¿Cómo calcular la relación Beneficio - Costo?

    .row.justify-content-center.align-items-center.mb-5.fnd-4(data-aos="zoom-in")
      .col-lg-12.p-4        
        SlyderA.fnd-5.p-4(tipo="b")
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 1
              p Para calcular lo primero que deben hacer es pasar los datos al archivo en Excel, como se muestra en la siguiente figura:
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-30.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 2
              p Se procede a efectuar el VNA de los ingresos como se muestra a continuación:
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-31.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 3
              p Se oprime la celda enter y se obtiene el resultado respectivo.
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-32.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 4
              p Se procede a efectuar el mismo procedimiento con los egresos.
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-33.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 5
              p Al darle enter se obtiene el valor del VNA de los Egresos
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-34.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 6
              p  Luego se procede a sumar el VNA de los Egresos con la inversión
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-35.png')
          .row.justify-content-center.align-items-center
            .col-md-5.mb-4.mb-md-0
              h5 Paso 7
              p Finalmente, la R B/C, se determina dividiendo el VNA de los Ingresos con el VNA de los Egresos + Inversión.
            .col-md-7
              figure.p-4
                img(src='@/assets/curso/temas/tema1/img-36.png')

    p Después de haber desarrollado los respectivos indicadores se procede a efectuar los análisis y la toma decisiones.

    Separador
    #1_2.titulo-segundo.color-acento-contenido(data-aos="zoom-in")
      h2 1.2 Evaluación económica y social

    .row.justify-content-center.align-items-center
      .col-lg-8
        p La evaluación económica y social, es aquella que permite identificar las cualidades que tiene un proyecto, indiferente de la situación financiera, por lo que no es un factor relevante, la distribución de las utilidades, tiene como propósito, identificar el impacto que tiene el proyecto sobre el bienestar económico del país.
        p La evaluación económica difiere de la evaluación financiera, la primera pretende medir el rendimiento del proyecto en términos de recursos reales para la sociedad, la segunda se estima el rendimiento de un proyecto. 
        p Para efectuar la evaluación económica y social se deben utilizar la Tasa Social de Descuento (TSD), que para el caso de Colombia se ha calculado en el 12%, queriendo decir con esto, que la rentabilidad esperada en el proyecto de inversión pública debe estar por encima de este valor.
        p De igual forma, para la evaluación económica y social se debe medir con los costos verdaderos de oportunidad y no con los costos del mercado, estos se conocen como precios sombra o precios cuenta.
        p Para proceder a realizar la evaluación económica y social se deben tener en cuenta, el anexo: Actualización de la estimación de los indicadores “Razón Precio-Cuenta”.
      .col-lg-4.col-md-8
        figure.p-4
          img(src='@/assets/curso/temas/tema1/img-37.svg')

    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .list.mb-3(data-aos="fade-down")
        .list__item
          .list__item__icon
            img(src='@/assets/curso/temas/tema1/img-2.svg', alt='')
        .list__txt
          h3.mb-0 Diferencias entre el análisis financiero y el económico y social

    p.mb-5 De acuerdo a lo evidenciado en la evaluación de un proyecto, se denotan diferencias significativas entre la evaluación financiera y la evaluación económica y social, como se muestra a continuación :
    .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
      .col-lg-10
        .titulo-sexto.color-acento-contenido
          h5 Tabla 6.
          span Diferencias Análisis Económico y Social vs. Análisis Financiero
      .col-lg-10.fnd-7
        .row.justify-content-center.align-items-center
          h5.mt-4.text-center Diferencias Análisis Económico y Social vs. Análisis Financiero

        .row.justify-content-center.align-items-stretch(data-aos="fade-right")
          .col-xl-6.mb-5
            .row.justify-content-center.align-items-stretch.fnd-8.fnd-8-1.px-5.py-3

                h5.mb-0.ln.text-center Análisis económico y social
                p.px-0.mt-3 Productividad
                p.px-0.mb-0 Rentabilidad
                p.mb-0.ln Crecimiento económico
                p.mb-0.ln Sociedad, comunidad
                p.mb-0.ln Distribución del ingreso
                p.mb-0.ln Precios cuenta
                p.px-0.mt-3.mb-2 Los impuestos son beneficios para la sociedad
                p.mb-0.ln Un subsidio es un costo para la sociedad
                p.px-0.mt-3 El estudio económico determina si el proyecto contribuye al desarrollo de la economía

          .col-xl-6.mb-5
            .row.justify-content-center.align-items-stretch.fnd-8.fnd-8-2.px-5.py-3
              
                h5.mb-0.ln2.text-center Análisis financiero
                p.px-0.mt-3.mb-2 Rendimiento de capital
                p.mb-0.ln2 Rendimiento privado
                p.mb-0.ln2 Inversionistas
                p.mb-0.ln2 Repartición de utilidades
                p.mb-0.ln2 Precios de mercado
                p.px-0.mt-3.mb-2 Los impuestos son costos
                p.mb-0.ln2 Los subsidios son ingresos
                p.px-0.mt-3.mb-2 El estudio financiero se refiere a la capacidad de obtener ganancias
      .col-lg-10        
        figcaption.mt-1 Nota. Elaboración propia.


    .row.justify-content-center.align-items-center(data-aos="fade-left")
      .col-xl-10
        .img-fnd-flot2.mb-3
          img.b-img2(src='@/assets/curso/temas/tema1/fnd-3.svg')
          .fl-box2
            p.mb-3 Finalmente, la evaluación de proyectos permite estimar los costos y beneficios desde la óptica financiera y los costos y beneficios económicos desde la óptica económica, se construyen los indicadores financieros, los cuales de acuerdo a los resultados obtenidos (viable o no viable), permiten tomar la decisión de continuar con el proyecto.



 









</template>

<script>
export default {
  name: 'Tema1',
  components: {},
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
