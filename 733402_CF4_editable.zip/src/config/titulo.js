module.exports =
  'Evaluación financiera y plan de acción estratégico de un proyecto agropecuario'
